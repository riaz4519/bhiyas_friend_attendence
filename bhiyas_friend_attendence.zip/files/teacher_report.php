
<!--top meta tags-->
<?php include "../partials/header_meta.php"?>

<!--after submit-->
<?php
include 'action/Connection.php';
include 'action/Teacher.php';
include 'action/Semester.php';
include 'action/Student.php';
include 'action/Course.php';
include 'action/Download.php';

?>

<?php

if (isset($_POST['download'])){



    $current = $_SERVER['HTTP_REFERER'];

    $selected_course = $_POST['course_id'];

    $teacher_id = $_SESSION['teacher_id'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $semester_id = $_POST['semester_id'];

    $download = new Download();

   $download->dload($semester_id,$teacher_id,$selected_course,$start_date,$end_date);

    //header('Location: '.$current);

}

?>

<!--title tag will be there always-->
<title>Teacher Dashboard</title>

<!--style bootstrap css -->
<?php include '../partials/basic_css.php'?>

<!--extra css-->

<!--end extra css-->

<!--middle head and body tag-->
<?php include "../partials/header_middle.php"; ?>

<!--content goes here-->


<!--nav header-->
<?php include 'header_nav_teacher.php' ?>
<!--end nav header -->

<!--side nav-->
<div class="container-fluid mt-3">
    <div class="row">

        <div class="col-2">

            <?php include 'side_nav_teacher.php'?>

        </div>


        <div class="col-10">
            <div class="row justify-content-center">

                <div class="col-11">

                    <!--getting all the teacher-->
                    <div class="card">

                        <div class="card-header">

                            <h3 class="text-center">Get Report</h3>

                        </div>
                        <div class="card-body">

                            <!--search teachers course -->

                            <div class="search-for-teacher">

                                <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="get">

                                    <div class="form-row">

                                        <!--getting the semester-->
                                        <div class="col">

                                            <label for="semester">Select Semester</label>
                                            <select id="semester" name="semester" class="form-control" required>
                                                <option disabled></option>
                                                <?php

                                                $semester = new Semester();

                                                $semesters  = $semester->getAllSemester();

                                                while ($single_semester = $semesters->fetch_object()){



                                                    ?>

                                                    <option  value="<?php echo $single_semester->id ?>"><?php echo $single_semester->semester ?></option>

                                                    <?php

                                                }
                                                ?>


                                            </select>

                                        </div>

                                        <!--end of getting the semester-->
                                        <div class="col">

                                            <label for="submit">..</label>
                                            <input id="submit" type="submit" class="form-control btn btn-secondary" name="search_course" value="Get Course">

                                        </div>




                                    </div>

                                </form>

                            </div>

                            <!--end of search teacher course-->

                        </div>

                    </div>



                    <!--end of getting teacher-->






                </div>

            </div>


            <!--show student added course and left courses-->

            <?php

            if (isset($_GET['semester'])){




                ?>

                <div class="row justify-content-center mt-5">


                    <!--already added-->
                    <div class="col-11">

                        <div class="card">

                            <div class="card-header">

                                <h3 class="text-center">Download Report</h3>

                            </div>
                            <div class="card-body">

                                <!--course -->

                                <!--course -->

                                <div class="search-for-course">

                                    <form id="download_report_form" action="action/dload.php" method="post">


                                        <input type="text" id="semester_id" name="semester_id" value="<?php echo $_GET['semester'] ?>" hidden>
                                        <input type="text" id="teacher_id" name="teacher_id" value="<?php echo $_SESSION['teacher_id'] ?>" hidden>


                                        <?php

                                        $course = new Course();

                                        $semester_id = $_GET['semester'];

                                        $courses = $course->getAllCourseOfTeacher($semester_id);


                                        ?>

                                        <div class="form-row">

                                            <div class="col">
                                                <label for="course_name">Course Name</label>
                                                <select id="course_id" name="course_id" class="form-control" required>




                                                    <?php

                                                    while ($single_course = $courses->fetch_object()){


                                                        ?>

                                                        <option value="<?php echo $single_course->id ?>"><?php echo  $single_course->course_name ?></option>



                                                        <?php

                                                    }
                                                    ?>
                                                </select>

                                            </div>

                                            <div class="col">

                                                <div class="form-row">

                                                    <div class="col">
                                                        <label for="start_date">Start Date</label>
                                                        <input id="start_date" name="start_date" type="date" class="form-control" required>
                                                    </div>
                                                    <div class="col">
                                                        <label for="end_date">End Date</label>
                                                        <input id="end_date" name="end_date" type="date" class="form-control" required>
                                                    </div>

                                                </div>



                                            </div>


                                        </div>
                                        <?php


                                        ?>


                                        <a href=""  id="download_button" class="btn btn-secondary mt-5 text-center" style="display: none">Download</a>

                                    </form>

                                </div>

                                <!--end  course-->

                                <!--end  course-->

                            </div>

                        </div>

                    </div>
                    <!--end of already added-->




                </div>

            <?php }  ?>

            <!--end of student added course and left courses-->


        </div>

    </div>
</div>
<!--end side nav-->


<!--end of content-->

<!--scripts jquery and bootstrap-->
<?php include "../partials/basic_script.php"; ?>

<script>
    $(document).ready(function () {


        var start_date = $('#start_date');

        var end_date = $('#end_date');



        var bool_start = false;

        var bool_end = false;

        start_date.on('change',function () {

            checkForProceed();
            bool_start = true;

        });

        end_date.on('change',function () {

            checkForProceed();
            bool_end = true;
        });



        function checkForProceed() {

            var downloadButton = $('#download_button');


            if (start_date.val().length > 0 && end_date.val().length > 0){

                var teacher_id = $('#teacher_id').val();
                var semester_id = $('#semester_id').val();
                var course_id = $('#course_id').val();
                var startDateValue = start_date.val();
                var endDateValue = end_date.val();
                downloadButton.attr('href',`action/dload.php?teacher_id=${teacher_id}&semester_id=${semester_id}&course_id=${course_id}&start_date=${startDateValue}&end_date=${endDateValue}`);
                downloadButton.show();
            } else{

                downloadButton.hide();
            }


        }





    });
</script>

<!--footer tags body and html-->
<?php include "../partials/footer_tag.php"; ?>
